import hashlib
import os

def token():
    return hashlib.sha256(os.urandom(32)).hexdigest()

def sanitize(s):
    return s.strip().replace("\x00", "")
