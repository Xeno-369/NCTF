import os

DB_URL = os.environ.get("DATABASE_URL", "sqlite:///dev.db")
DEBUG = os.environ.get("DEBUG", "0") == "1"
